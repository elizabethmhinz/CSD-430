package libraryProject;
//June 22, 2025 by Liz Hinz for CSD430-A339: Server Side Development 
//Java class for table to connect to CSD430 database 

import java.sql.*;
import java.util.*;

public class LibraryAccessData implements java.io.Serializable {
    private static final long serialVersionUID = 111222333444L;
    private Connection connection;
    private Statement statement; 

    // Connect to database
    public LibraryAccessData() {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            String url = "jdbc:mysql://localhost:3306/CSD430?user=student1&password=pass";
            connection = DriverManager.getConnection(url);
            statement = connection.createStatement();
        } catch (ClassNotFoundException | SQLException e) {
            System.out.print("SQL Exception:" + e);
        }
    }
    
    // Method for InsertLibraryData.jsp
    public String insertDefaultRecords() {
        try{
        	String[] inserts = {
            "INSERT INTO LibraryTableData(Title, Author, Genre, YearPublished, ISBN) VALUES('A Tale of Two Cities', 'Charles Dickens','Historical fiction', 1859, '978-0582030473')",
            "INSERT INTO LibraryTableData(Title, Author, Genre, YearPublished, ISBN) VALUES('The Alchemist', 'Paulo Coelho','Fantasy', 1988, '978-0061122415')",
           	"INSERT INTO LibraryTableData(Title, Author, Genre, YearPublished, ISBN) VALUES('Harry Potter and the Philosopher''s Stone', 'J. K. Rowling','Fantasy', 1997, '978-1408855652')",
            "INSERT INTO LibraryTableData(Title, Author, Genre, YearPublished, ISBN) VALUES('And Then There Were None', 'Agatha Christie','Mystery', 1939, '978-0062073488')",
            "INSERT INTO LibraryTableData(Title, Author, Genre, YearPublished, ISBN) VALUES('The Hobbit', 'J.R.R. Tolkien','Fantasy', 1937, '978-0345445605')",
           	"INSERT INTO LibraryTableData(Title, Author, Genre, YearPublished, ISBN) VALUES('Alice''s Adventures in Wonderland', 'Lewis Carroll','Fantasy', 1865, '978-0977716173')",
            "INSERT INTO LibraryTableData(Title, Author, Genre, YearPublished, ISBN) VALUES('The Da Vinci Code', 'Dan Brown','Mystery Thriller', 2003, '978-0739339787')",
            "INSERT INTO LibraryTableData(Title, Author, Genre, YearPublished, ISBN) VALUES('The Catcher in the Rye', 'J. D. Salinger','Coming-of-age', 1951, '978-3462015393')",
            "INSERT INTO LibraryTableData(Title, Author, Genre, YearPublished, ISBN) VALUES('The Bridges of Madison County', 'Robert James Waller','Romance', 1992, '978-0099421344')",
            "INSERT INTO LibraryTableData(Title, Author, Genre, YearPublished, ISBN) VALUES('To Kill a Mockingbird', 'Harper Lee','Southern Gothic', 1960, '978-2253115847')"
        	};
        	
        	for (String sql : inserts) {
        		statement.executeUpdate(sql);
        	}
        	return "All default records inserted successfully.";
    	} catch (SQLException e) {
    		return "Insert Error: " + e.getMessage();
    	}
	}
    
    // Method for CreateLibraryTable.jsp
    public String createTable() {
        try {
            statement.executeUpdate("DROP TABLE IF EXISTS LibraryTableData");
            statement.executeUpdate(
                "CREATE TABLE LibraryTableData(" +
                "Title VARCHAR(100) NOT NULL, " +
                "Author VARCHAR(100) NOT NULL, " +
                "Genre VARCHAR(50) NOT NULL, " +
                "YearPublished INT NOT NULL, " +
                "ISBN VARCHAR(20) NOT NULL PRIMARY KEY)"
            );
            return "Table created successfully.";
        } catch (SQLException e) {
            return "Create Table Error: " + e.getMessage();
        }
    }
    
    // method to get titles for SelectLibraryData
    public List<String> getAllTitles() {
        List<String> titles = new ArrayList<>();
        try (ResultSet rs = statement.executeQuery("SELECT Title FROM LibraryTableData ORDER BY Title")) {
            while (rs.next()) {
                titles.add(rs.getString("Title"));
            }
        } catch (SQLException e) {
            titles.add("Error: " + e.getMessage());
        }
        return titles;
    }

    // method to get dislpay titles for SelectLibraryData
    public String readByTitle(String title) {
        try (PreparedStatement ps = connection.prepareStatement("SELECT * FROM LibraryTableData WHERE Title = ?")) {
            ps.setString(1, title);
            ResultSet rs = ps.executeQuery();
            StringBuilder sb = new StringBuilder();
            sb.append("<table border='1'><thead><tr><th>Title</th><th>Author</th><th>Genre</th><th>Year</th><th>ISBN</th></tr></thead><tbody>");
            while (rs.next()) {
                sb.append("<tr>")
                  .append("<td>").append(rs.getString("Title")).append("</td>")
                  .append("<td>").append(rs.getString("Author")).append("</td>")
                  .append("<td>").append(rs.getString("Genre")).append("</td>")
                  .append("<td>").append(rs.getInt("YearPublished")).append("</td>")
                  .append("<td>").append(rs.getString("ISBN")).append("</td>")
                  .append("</tr>");
            }
            sb.append("</tbody></table>");
            return sb.toString();
        } catch (SQLException e) {
            return "Select Error: " + e.getMessage();
        }
    }
    
    // Method for updateRecord2 
    public String updateRecord(String title, String author, String genre, String year, String isbn) {
        String sql = "UPDATE LibraryTableData SET Author = ?, Genre = ?, YearPublished = ?, ISBN = ? WHERE Title = ?";
        try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
            pstmt.setString(1, author);
            pstmt.setString(2, genre);
            pstmt.setString(3, year);
            pstmt.setString(4, isbn);
            pstmt.setString(5, title);

            int rows = pstmt.executeUpdate();
            return rows + " record(s) updated.";
        } catch (SQLException e) {
            return "SQL Exception: " + e.getMessage();
        }
    }

    // Update Record 
    public String updateLibrary(String title, String author, String genre, int yearPublished, String ISBN) {
        String sql = "UPDATE LibraryTableData SET Title = ?, Author = ?, Genre = ?, YearPublished = ? WHERE ISBN = ?";
        try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
            pstmt.setString(1, title);
            pstmt.setString(2, author);
            pstmt.setString(3, genre);
            pstmt.setInt(4, yearPublished);
            pstmt.setString(5, ISBN);
            int rowsUpdated = pstmt.executeUpdate();
            return (rowsUpdated > 0) ? "Record updated successfully." : "No record was updated.";
        } catch (SQLException e) {
            return "SQL Exception:" + e;
        }
    }

    // Create Record — now returns status String
    public String createRecord(String title, String author, String genre, int yearPublished, String isbn) {
        String sql = "INSERT INTO LibraryTableData (Title, Author, Genre, YearPublished, ISBN) VALUES (?, ?, ?, ?, ?)";
        try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
            pstmt.setString(1, title);
            pstmt.setString(2, author);
            pstmt.setString(3, genre);
            pstmt.setInt(4, yearPublished);
            pstmt.setString(5, isbn);
            pstmt.executeUpdate();
            return "Record added successfully.";
        } catch (SQLException e) {
            return "SQL Exception: " + e.getMessage();
        }
    }

    // Read all records
    public String readAll() { 
        StringBuilder sb = new StringBuilder();
        String sql = "SELECT * FROM LibraryTableData";
        sb.append("<table border='1' bgcolor='blue'>");
        sb.append("<thead><tr>");
        sb.append("<th>Title</th>");
        sb.append("<th>Author</th>");
        sb.append("<th>Genre</th>");
        sb.append("<th>Year Published</th>");
        sb.append("<th>ISBN</th>");
        sb.append("</tr></thead><tbody>");
        try (ResultSet rs = statement.executeQuery(sql)) {
            while(rs.next()) {
                sb.append("<tr>");
                for (int i = 1; i <= rs.getMetaData().getColumnCount(); i++) {
                    sb.append("<td>").append(rs.getString(i).trim()).append("</td>");
                }
                sb.append("</tr>");
            }
        } catch(SQLException e) {
            sb.append("<tr><td colspan='5'>SQL Exception: ").append(e.getMessage()).append("</td></tr>");
        }
        sb.append("</tbody></table>");
        return sb.toString();
    }

    // Read record by ISBN
    public String readByISBN(String ISBN) {
        StringBuilder sb = new StringBuilder();
        String sql = "SELECT * FROM LibraryTableData WHERE ISBN = ?";
        sb.append("<table border='1' bgcolor='#ADD8E6'>");
        sb.append("<thead><tr>");
        sb.append("<th>Title</th>");
        sb.append("<th>Author</th>");
        sb.append("<th>Genre</th>");
        sb.append("<th>Year Published</th>");
        sb.append("<th>ISBN</th>");
        sb.append("</tr></thead><tbody>");
        try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
            pstmt.setString(1, ISBN);
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    sb.append("<tr>");
                    for (int i = 1; i <= rs.getMetaData().getColumnCount(); i++) {
                        sb.append("<td>").append(rs.getString(i).trim()).append("</td>");
                    }
                    sb.append("</tr>");
                } else {
                    sb.append("<tr><td colspan='5'>No record found with ISBN ").append(ISBN).append("</td></tr>");
                }
            }
        } catch (SQLException e) {
            sb.append("<tr><td colspan='5'>SQL Exception: ").append(e.getMessage()).append("</td></tr>");
        }
        sb.append("</tbody></table>");
        return sb.toString();
    }

    // deleteByTitle to match JSP call
    public String deleteByTitle(String title) {
        String sql = "DELETE FROM LibraryTableData WHERE Title = ?";
        try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
            pstmt.setString(1, title);
            int rows = pstmt.executeUpdate();
            return rows + " record(s) deleted.";
        } catch (SQLException e) {
            return "SQL Exception: " + e.getMessage();
        }
    }
    
    // titleToDelete to match JSP call 

    public String titleToDelete(String title) {
        String sql = "DELETE FROM LibraryTableData WHERE Title = ?";
        try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
            pstmt.setString(1, title);
            int rows = pstmt.executeUpdate();
            return rows + " record(s) deleted.";
        } catch (SQLException e) {
            return "SQL Exception: " + e.getMessage();
        }
    }    
    

    // Close database connection
    public void closeConnection() {
        try {
            if (statement != null) statement.close();
            if (connection != null) connection.close();
        } catch (SQLException e) {
            System.out.println("SQL Exception: " + e.getMessage());
        }
    }
}

