-- June 29, 2025 - SQL Statement for Database by Liz Hinz for CSD430-A339 Library/CRUD Project

-- Create Database
CREATE DATABASE IF NOT EXISTS CSD430;
USE CSD430;

-- Drop table
DROP TABLE IF EXISTS LibraryTableData;

-- Create table
CREATE TABLE LibraryTableData(
	Title VARCHAR(100) NOT NULL, 
	Author VARCHAR(100) NOT NULL, 
	Genre VARCHAR(50) NOT NULL, 
	YearPublished INT NOT NULL, 
	ISBN VARCHAR(20) NOT NULL PRIMARY KEY)");

-- Populate Table
INSERT INTO LibraryTableData(Title, Author, Genre, YearPublished, ISBN)VALUES
('A Tale of Two Cities', 'Charles Dickens','Historical fiction', '1859', '978-0582030473'),
('The Alchemist', 'Paulo Coelho','Fantasy', '1988', '978-0061122415'),
('Harry Potter and the Philosopher''s Stone', 'J. K. Rowling','Fantasy', '1997', '978-1408855652'),
('And Then There Were None', 'Agatha Christie','Mystery', '1939', '978-0062073488'),
('The Hobbit', 'J.R.R. Tolkien','Fantasy', '1937', '978-0345445605')");
('Alice''s Adventures in Wonderland', 'Lewis Carroll','Fantasy', '1865', '978-0977716173'),
('The Da Vinci Code', 'Dan Brown','Mystery Thriller', '2003', '978-0739339787'),
('The Catcher in the Rye', 'J. D. Salinger','Coming-of-age', '1951', '978-3462015393'),
('The Bridges of Madison County', 'Robert James Waller','Romance', '1992', '978-0099421344'),
('To Kill a Mockingbird', 'Harper Lee','Southern Gothic', '1960', '978-2253115847');