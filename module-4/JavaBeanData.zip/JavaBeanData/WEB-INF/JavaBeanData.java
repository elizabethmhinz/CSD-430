// June 15, 2025 - Created by Liz Hinz for CSD430-A339: Server Side Development
// JavaBean to hold data from JSP Page 

package coffeeBeans;

//Implement Serializable 
public class JavaBeanData implements java.io.Serializable {
	
	private static final long serialVersionUID = 12345678L;

	private String name;
	private String genre;
	private String director;
	// Added two more input. total now 5
	private String releaseYear;
	private String starRating;
	
	// Constructor 
	public JavaBeanData() {
		
	}
	// Constructor with name, genre, director, release year, & rating fields 
	public JavaBeanData(String name, String genre, String director, String releaseYear, String starRating) {
		this.name = name;
		this.genre = genre;
		this.director = director;
		this.releaseYear = releaseYear;
		this.starRating = starRating;
	}
	
	// Getter method for name
	public String getName() {
		return this.name;
	}
	
	// Setter method for name
	public void setName(String name) {
		this.name = name;
	}
	
	// Getter method for genre
	public String getGenre() {
		return this.genre;
	}
	
	// Setter method for genre
	public void setGenre(String genre) {
		this.genre = genre;
	}
	
	// Setter method for director
	public String getDirector() {
		return this.director;
	}
	
	// Getter method for director 
	public void setDirector(String director) {
		this.director = director;
	}
	// Setter method for release year
	public String getReleaseYear() {
		return this.releaseYear;
	}
	
	// Getter method for release year 
	public void setReleaseYear(String releaseYear) {
		this.releaseYear = releaseYear;
	}
	// Setter method for rating
	public String getStarRating() {
		return this.starRating;
	}
	
	// Getter method for rating 
	public void setStarRating(String starRating) {
		this.starRating = starRating;
	}
}

