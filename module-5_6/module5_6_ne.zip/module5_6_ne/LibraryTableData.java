package module5_6;

// June 22, 2025 by Liz Hinz for CSD430-A339: Server Side Development 
// Java class for table in CSD430 database 

public class LibraryTableData implements java.io.Serializable { // Implement serializable
	
	private static final long serialVersionUID = 12345678L;

	// 5 input fields 
	private String title;
	private String author;
	private String genre;
	private String yearPublished;
	private String ISBN;
	
	// Constructor 
	public LibraryTableData() {
		
	}
	// Constructor with name, genre, director, release year, & rating fields 
	public LibraryTableData (String title, String author, String genre, String yearPublished, String ISBN) {
		this.title = title;
		this.author = author;
		this.genre = genre;
		this.yearPublished = yearPublished;
		this.ISBN = ISBN;
	}
	
	// Getter method for title
	public String getTitle() {
		return this.title;
	}
	
	// Setter method for title
	public void setTitle(String title) {
		this.title = title;
	}
	
	// Getter method for author
	public String getAuthor() {
		return this.author;
	}
	
	// Setter method for author
	public void setAuthor(String author) {
		this.author = author;
	}
	
	// Setter method for genre
	public String getGenre() {
		return this.genre;
	}
	
	// Getter method for genre 
	public void setGenre(String genre) {
		this.genre = genre;
	}
	// Setter method for year published 
	public String getYearPublished() {
		return this.yearPublished;
	}
	
	// Getter method for year published 
	public void setYearPublished(String yearPublished) {
		this.yearPublished = yearPublished;
	}
	// Setter method for ISBN
	public String getISBN() {
		return this.ISBN;
	}
	
	// Getter method for ISBN 
	public void setISBN(String ISBN) {
		this.ISBN = ISBN;
	}
}
