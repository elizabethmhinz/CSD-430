package module5_6;

//June 22, 2025 by Liz Hinz for CSD430-A339: Server Side Development 
//Java class for table in CSD430 database 

import java.sql.*;

// Implement Serializable for javabean
public class LibraryAccessData implements java.io.Serializable {
    private static final long serialVersionUID = 111222333444L;
	private Connection connection;
	private Statement statement; 

	// Constructor 
	public LibraryAccessData() {
	    try {
	    	Class.forName("com.mysql.cj.jdbc.Driver");
	    	String url = "jdbc:mysql://localhost:3306/CSD430?user=student1&password=pass";
	    	connection = DriverManager.getConnection(url);
	    	statement = connection.createStatement();
	    	}
	    	catch(ClassNotFoundException | SQLException e) {
	    		System.out.print("SQL Exception:" + e);
	    	}
	    }

	// Update Record 
	public String updateRecord(String title, String author, String genre, int yearPublished , String ISBN) {
   		String sql = "UPDATE LibraryTableData SET Title = ?, Author = ?, Genre = ?, YearPublished = ? WHERE ISBN = ?";
	   	try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
	   		pstmt.setString(1, title);
	   		pstmt.setString(2, author);
	   		pstmt.setString(3, genre);
	   		pstmt.setInt(4, yearPublished);
	   		pstmt.setString(5, ISBN);
	   		pstmt.executeUpdate();
	   		return "Update complete.";
	    	}
	    	catch(SQLException e) {
	    		return "SQL Exception:" + e;
	    	}
	    }
	    
	// Create Record 
	public void createRecord(String title, String author, String genre, int yearPublished, String ISBN) {
	    try {		   		
	   		String sql = "INSERT INTO LibraryTableData (Title, Author, Genre, YearPublished, ISBN) VALUES (?, ?, ?, ?, ?)";
	   		PreparedStatement pstmt = connection.prepareStatement(sql);
	   		pstmt.setString(1, title);
	   		pstmt.setString(2, author);
	   		pstmt.setString(3, genre);
	   		pstmt.setInt(4, yearPublished);
	   		pstmt.setString(5, ISBN);
	   		pstmt.executeUpdate();
	   		pstmt.close();
	    	}
	    	catch(SQLException e) {
	    		System.out.print("SQL Exception: " + e);
	    	}
	    }
	
	// Read all records    
	public String readAll() { 
		StringBuilder sb = new StringBuilder();
		String sql = "SELECT * FROM LibraryTableData";
	    try (ResultSet rs = statement.executeQuery(sql)) {
	    	sb.append("<table border='1' bgcolor='blue'>");
	    	while(rs.next()) {
	    		sb.append("<tr>");
	    		sb.append("<thead><tr>");
	    		sb.append("<th>Title</th>");
	    		sb.append("<th>Author</th>");
	    		sb.append("<th>Genre</th>");
	    		sb.append("<th>Year Published</th>");
	    		sb.append("<th>ISBN</th>");
	    		sb.append("</tr></thead>");

	    		for (int i = 1; i <= rs.getMetaData().getColumnCount(); i++) {
	    			sb.append("<td>").append(rs.getString(i).trim()).append("</td>");
	    		}
	    		sb.append("</tr>");
	    	}
	    	sb.append("</table>");
	    } 
	    catch(SQLException e) {
	    	sb.append("SQL Exception:").append(e);
	    	}
	    return sb.toString();
	    }
	
	// Read record by ISBN
	public String readByISBN(String ISBN) {
		StringBuilder sb = new StringBuilder();
	    try {
	    	String sql = "SELECT * FROM LibraryTableData WHERE ISBN = ?";
	        PreparedStatement pstmt = connection.prepareStatement(sql);
	        pstmt.setString(1, ISBN);
	        ResultSet rs = pstmt.executeQuery();
	        sb.append("<table border='1' bgcolor='#ADD8E6'>");
	        sb.append("<thead><tr>");
	        sb.append("<th>Title</th>");
	        sb.append("<th>Author</th>");
	        sb.append("<th>Genre</th>");
	        sb.append("<th>Year Published</th>");
	        sb.append("<th>ISBN</th>");
	        sb.append("</tr></thead>");

	        while (rs.next()) {
	        	sb.append("<tr>");
	                for (int i = 1; i <= rs.getMetaData().getColumnCount(); i++) {
	                    sb.append("<td>").append(rs.getString(i).trim()).append("</td>");
	                }
	                sb.append("</tr>");
	            }
	            sb.append("</table>");
	            rs.close();
	            pstmt.close();
	        } catch (SQLException e) {
	            sb.append("SQL Exception: ").append(e);
	        }
	        return sb.toString();
	    }
	
	// Delete record by ISBN
	public String delete(String ISBN) {
		String sql = "DELETE FROM LibraryTableData WHERE ISBN = ?";
		try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
	        pstmt.setString(1, ISBN);
	        int rows = pstmt.executeUpdate();
	        return rows + " record(s) deleted.";
	        } catch (SQLException e) {
	            return "SQL Exception: " + e;
	    }
	}
		
	// Close database connection
	public void closeConnection() {
		try {
			if (statement != null) statement.close();
	        if (connection != null) connection.close();
	    } catch (SQLException e) {
	    	System.out.println("SQL Exception: " + e);
	    }
	}
}

	    	

